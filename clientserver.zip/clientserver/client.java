import java.net.*;

import java.io.*;



public class clients
{
	
	private static Socket socket;
	
	public static void main(String args[])
	
{

		
try
		
{
			
	String host = "192.168.220.131";
			
	int port = 8080;
			
	InetAddress address = InetAddress.getByName(host);
			
	socktt = new Socket(address,port);

			


			
	OutputStream os = socktt.getOutputStream();
			
	OutputStreamWriter ost = new OutputStreamWriter(os);
			
	BufferedWriter bw = new BufferedWriter(ost);

			
	String msg = "Hello World";
			
	String sendMessage = msg + "\n";
			
	bw.write(sendMessage);
			
	bw.flush();
			

	System.out.println("Message sent to the server: " + sendMessage);

			


			
	InputStream is = socktt.getInputStream();
			
	InputStreamReader ist = new InputStreamReader(is);
			
	BufferedReader br = new BufferedReader(ist);
			
	String message = br.readLine();
	
		
	System.out.println("Message received from the server: " + message);
		
	}
		

	catch (Exception exception)
		
	{
			
		exception.printStackTrace();
		
	}
		

	finally
		
	{
			
	
			
		try
			
		{
				
			socktt.close();
			
		}
			
		catch (Exception e)
			
		{
				
			e.printStackTrace();
			
		}
		
	}
	
	}

}
