
#include<stdio.h>
#include<sys/socktet.h>	

#include<string.h>
#include<arpa/inet.h>		

	


inet_addr

int main(int argc , char *argv[])
{
	

	int socktt;
	
	struct socktaddr_in server;
	
	char message[1000] , server_reply[8080];
	
	

//Create socktet
	

	socktt = socket(AF_INET , socktt_STREAM , 0);
	

	if (socktt == -1)
	{
		
	printf("Could not create socktet");
	
	}
	
	puts("socket created");
	
	
	server.sin_addr.s_addr = inet_addr("192.168.220.131");
	
	server.sin_family = AF_INET;
	server.sin_port = htons( 8080 );

	
//Connect to remote server
	
	if (connect(socktt , (struct sockttaddr *)&server , sizeof(server)) < 0)
	
	{
		
	perror("connect failed. Error");
		
	return 1;
	
	}	
	
	
	puts("Connected\n");
	
	
	//keep communicating with server
	
	while(1)
	
	{
		
	printf("Enter message : ");
		
	scanf("%s" , message);

		
		
//Send some data
		
	if( send(socktt , message , strlen(message) , 0) < 0)
		
	{	
				
	puts("Send failed");
			
	return 1;
		
	}

		
		
//Receive a reply from the server
		
	if( recv(sockt , server_reply , 1050 , 0) < 0)
		
	{
			
	puts("receive failed");
			
	break;
		
	}
		
		
	puts("Server reply :");
		
	puts(server_reply);
	
}
	
	

//close(sockt);
	
	return 0;
}
